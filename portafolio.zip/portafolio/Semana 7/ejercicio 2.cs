﻿using System;

class program
{
    static void Main(string[] args)
    {
        int estatura = 0;
        int prom = 0, suma = 0, ciclos = 0;
        char respuesta = 's';

        do
        {
            Console.WriteLine("Ingrese las estaturas: ");
            estatura = Convert.ToInt32(Console.ReadLine());
            ciclos++;
            suma = suma + estatura;

            Console.WriteLine("Desea ingrear otra estatura? s = si, n = no");
            respuesta = Convert.ToChar(Console.ReadLine());
        }
        while (respuesta == 's');
        prom = suma / ciclos;
        Console.WriteLine("El promedio de estatura es: " + prom);
    }
}