﻿using System;

class program
{
    static void Main(string[] args)
    {
        int num;
        int suma = 0;
        for (int i = 0; i <= 100; i++)
        {
            Console.WriteLine("Ingrese un número: ");
            num = Convert.ToInt32(Console.ReadLine());

            suma = suma + num;
        }
        Console.WriteLine("La suma de todos los valores son: " + suma);
    }
}