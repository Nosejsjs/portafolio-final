﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_individual_semana_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 0, ciclos = 0, prom, suma = 0;
            bool valid;

            Console.WriteLine("Se le pedirán 10 valores para obtener su promedio");
            Console.WriteLine("Cada valor debe ser mayor a 0\n");
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("Ingrese el valor " + i);
                valid = int.TryParse(Console.ReadLine(), out n);
                while (!valid || n == 0)
                {
                    Console.WriteLine("Ingrese un valor mayor a 0 y NO ingrese letras");
                    valid = int.TryParse(Console.ReadLine(), out n);
                }
                suma = suma + n;
                ciclos++;
            }
            prom = suma / ciclos;
            Console.WriteLine("El promedio de valores es: " + prom);
            Console.WriteLine("Pulse enter para pasar al siguiente programa");
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Pulse enter para conocer los primeros 10 números primos \n");
            Console.ReadKey();

            int num = 2;
            int nprimos = 1;

            while (nprimos <= 10)
            {
                bool primo = true;

                for (int x = 2; x < num; x++)
                {
                    if (num % x == 0)
                    {
                        primo = false;
                        break;
                    }
                }
                if (primo)
                {
                    Console.WriteLine(num + " es primo");
                    nprimos++;
                }
                num++;
            }
            Console.WriteLine("Pulse enter para salir");
            Console.ReadKey();
        }
    }
}