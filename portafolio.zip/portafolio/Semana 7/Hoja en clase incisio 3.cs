﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class program // Josué Tzul 1067123 y Daniel del Cid 1009823
{
    static void Main(string[] args)
    {
        int precio = 0;
        int subtotal = 0;
        int cantidad = 0;
        int cantidad1 = 0;
        int ciclos = 0;
        int prom;
        int total=0;
        char respuesta = 's'; // s = si, n = no

        while (respuesta == 's')
        {
            Console.WriteLine("Ingrese el valor del producto ");
            precio = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("El valor del producto es: " + precio);

            Console.WriteLine("Ingrese la cantidad de producto ");
            cantidad = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("La cantidad que lleva es: " + cantidad);

            subtotal = precio * cantidad;
            Console.WriteLine("EL sub total es: " + subtotal);

            cantidad1 = cantidad + cantidad1;
            Console.WriteLine("La cantidad total que lleva es: " + cantidad1);
            total = total + subtotal;
            Console.WriteLine("El total es: " + total);

            Console.WriteLine("Desea ingresar otro valor? s = si, n = no");
            respuesta = Convert.ToChar(Console.ReadLine());

            ciclos++;
        }

        Console.WriteLine("Gracias");
        Console.ReadKey();
    }
}
