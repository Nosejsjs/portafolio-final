﻿using System;
namespace Desafio_1.Semana_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int meses, pago = 10, valor = 0;

            for (meses = 1; meses <= 20; meses++)
            {
                Console.WriteLine("El mes " + meses + " pagó: Q." + pago);
                pago = pago * 2;
                valor = valor + pago;
            }
            Console.WriteLine("El total que pagó fue: " + pago);
            Console.ReadKey();
        }
    }
}