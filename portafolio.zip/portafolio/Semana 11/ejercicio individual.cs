﻿using System;
using System.Globalization;
using System.Security.Cryptography.X509Certificates;

public class libro
{
    public int codin;
    public string nombre;
    public int pags;
    public int cant;
    public int porcen;

    public libro(int cod, string name, int npag, int can, int por)
    {
        codin = cod;
        nombre = name;
        pags = npag;
        cant = can;
        porcen = por;
    }

    //*leer cantidad de pags y contar, o algo asi*//
    public void leerpags(int npags)
    {
        npags = npags + 1;
        if (npags == 100)
        {
            Console.WriteLine("Leido");
        }
        else (npags > 100)
        {
            Console.WriteLine("ERROR");
        }

    //*Porcentaje*//
    public void porcentaje(int npags, int can, int por)
        {
            por = (npags / can)*100;
            return por;
        }

    //*Obtener y devolver pagina actual*//
    public void pagactual(int npags, int can)
        {
            can = npags;
        }

    //*mostrar libro*//
    public void mostrar(int npags, int cod, string name, int por)
        {
            Console.WriteLine(npags);
            Console.WriteLine(name);
            Console.WriteLine(por);
            Console.WriteLine(cod);
        }

    public void Main(string name, int cod, int name, int por, int can, int npags)
        {
            Console.WriteLine("ingrese el nombre del libro");
            string name = Convert.ToString(Console.ReadLine());
            Console.WriteLine("ingrese el numero de paginas");
            int npags = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese el codigo");
            int cod = Convert.ToInt32(Console.ReadLine());
        }
}